"""Deterministic report and optional AI-generated commentary."""
import os
from pathlib import Path

def make_report(db):
    s = db.stats()
    lines = [
        "DEAL RADAR v1.0 — аналитический отчёт",
        "Источник: учебные данные (не реальные предложения магазинов).",
        f"Товаров: {s['count']}",
        f"Средняя цена: {s['average'] if s['count'] else 'нет данных'} ₸",
        f"Минимальная цена: {s['minimum'] if s['count'] else 'нет данных'} ₸",
        f"Максимальная цена: {s['maximum'] if s['count'] else 'нет данных'} ₸",
        "",
        "Средние цены по магазинам:"
    ]
    store_rows = db.by_store()
    lines += [f"- {r['store']}: {r['average']} ₸ ({r['count']} шт.)"
              for r in store_rows]
    if len(store_rows) >= 2:
        low, high = store_rows[0], store_rows[-1]
        difference = round(high["average"] - low["average"], 2)
        lines.append(
            f"Сравнение: средняя цена в {low['store']} ниже, чем в "
            f"{high['store']}, на {difference} ₸."
        )
    elif store_rows:
        lines.append("Для сравнения средней цены нужны минимум два магазина.")
    else:
        lines.append("Магазины отсутствуют: сравнение средней цены невозможно.")
    lines += ["", "Топ падений цены между двумя последними замерами:"]
    discounts = db.top_discounts()
    lines += [f"- {r['name']} ({r['store']}): {r['old_price']} → "
              f"{r['new_price']} ₸ (-{r['drop_pct']}%)" for r in discounts]
    if not discounts:
        lines.append("- Падений цены не обнаружено")
    lines += ["", "Примечание: снижение цены не гарантирует выгодную покупку."]
    return "\n".join(lines)

def ai_report(statistics):
    """Optional OpenAI API; does not run without key and installed openai package."""
    if not os.getenv("OPENAI_API_KEY"):
        return None
    try:
        from openai import OpenAI
    except ImportError:
        raise RuntimeError("Установите пакет: pip install openai")
    client = OpenAI()
    response = client.responses.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
        instructions=("Ты осторожный аналитик цен. Используй ТОЛЬКО предоставленные "
                      "цифры. Отметь, что это учебные данные, а не реальные скидки. "
                      "Не выдумывай факты. Ответ на русском: 3–5 предложений."),
        input=statistics,
    )
    return response.output_text

def save_report(text, path="reports/report.txt"):
    dest = Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8")
    return dest
