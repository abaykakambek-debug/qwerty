import sqlite3
conn = sqlite3.connect('deals.db')
cur = conn.cursor()
cur.execute("""
CREATE TABLE IF NOT EXISTS stores (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL UNIQUE
        );
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    store_id INTEGER NOT NULL REFERENCES stores(id),
    price REAL NOT NULL CHECK(price >= 0),
    rating REAL CHECK(rating BETWEEN 0 AND 5),
    url TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS price_history (
    id INTEGER PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    price REAL NOT NULL CHECK(price >= 0),
    checked_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
""")
conn.commit()
conn.close()
