# Результаты SQL-запросов

## COUNT / AVG / MIN / MAX
```sql
SELECT COUNT(*) total, ROUND(AVG(price),2) avg_price, MIN(price) min_price, MAX(price) max_price FROM products
```

| total | avg_price | min_price | max_price |
| --- | --- | --- | --- |
| 8 | 68893.75 | 8500.0 | 299000.0 |

## GROUP BY + JOIN
```sql
SELECT s.name store, COUNT(*) products_count, ROUND(AVG(p.price),2) average_price FROM stores s JOIN products p ON p.store_id=s.id GROUP BY s.id ORDER BY average_price
```

| store | products_count | average_price |
| --- | --- | --- |
| AudioMall | 2 | 25875.0 |
| GadgetCity | 3 | 50666.67 |
| TechShop | 3 | 115800.0 |

## Пять самых дешёвых товаров
```sql
SELECT p.name, s.name store, p.price FROM products p JOIN stores s ON s.id=p.store_id ORDER BY p.price LIMIT 5
```

| name | store | price |
| --- | --- | --- |
| Мышь Aero | TechShop | 8500.0 |
| Колонка MiniBeat | AudioMall | 18000.0 |
| Веб-камера Clear | GadgetCity | 21000.0 |
| Клавиатура KeyPro | GadgetCity | 22000.0 |
| Наушники SoundX | AudioMall | 33750.0 |
